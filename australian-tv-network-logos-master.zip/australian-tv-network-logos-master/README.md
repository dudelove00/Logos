Australian TV network logos
===========================

Bunch of Aussie TV logos for use in MythTV, Kodi, whatever.

Samples
-------

![abc2](png/abc2.png)
![abc3](png/abc3.png)
![abc-news-24](png/abc-news-24.png)
![abc](png/abc.png)
![dig-radio](png/dig-radio.png)
![eleven](png/eleven.png)
![gem](png/gem.png)
![go](png/go.png)
![nbn](png/nbn.png)
![nine](png/nine.png)
![one](png/one.png)
![prime](png/prime.png)
![sbs](png/sbs.png)
![sbs-two](png/sbs-two.png)
![seven-mate](png/seven-mate.png)
![seven](png/seven.png)
![seven-two](png/seven-two.png)
![southern-cross-television](png/southern-cross-television.png)
![southern-cross-ten](png/southern-cross-ten.png)
![ten](png/ten.png)
![win](png/win.png)

Contributing
------------

If you want to contribute a new logo please:

1. Provide an original SVG logo you created yourself (or otherwise have the copyright over)
2. There is no build process, so just make a pull request with the SVG and I'll do the rest.

License
-------

The files are licensed as Creative Commons Attribution. The designs in the files are owned by the respective networks, so probably best these are just for personal use. :)

[![Creative Commons Attribution](https://i.creativecommons.org/l/by/4.0/88x31.png)](http://creativecommons.org/licenses/by/4.0/)
